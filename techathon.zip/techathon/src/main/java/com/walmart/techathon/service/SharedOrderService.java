package com.walmart.techathon.service;

import com.walmart.techathon.model.SharedOrder;
import com.walmart.techathon.model.SharedOrderRequest;

public class SharedOrderService {
	
	private SharedOrder createSharedOrder(SharedOrderRequest sharedOrderRequest) {
		return null;
	}

}
