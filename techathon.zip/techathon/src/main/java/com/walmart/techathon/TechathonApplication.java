package com.walmart.techathon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechathonApplication {

	public static void main(String[] args) {
		SpringApplication.run(TechathonApplication.class, args);
	}

}
