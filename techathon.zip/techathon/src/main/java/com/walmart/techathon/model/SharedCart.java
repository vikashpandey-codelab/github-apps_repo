package com.walmart.techathon.model;

import java.util.List;

public class SharedCart {
	
	private String userId;
	private List<Product> products;

}
