package com.walmart.techathon.model;

public class SharedOrderPickUpPoint {
	
	private String pickUpPointId;
	private String zipCode;
	private String city;
	private String StreetAddress;
	private String state;
	private String landMark;
	
	
	

}
