package com.walmart.techathon.model;

import java.util.List;

public class SharedOrderRequest {
	
	private List<OrderedProduct> itemsInOrder;
	private String UserId;
	private PickUpSlot slot;
	private SharedOrderPickUpPoint pickupPoint;
	private String pickUpstoreId;
	

}
