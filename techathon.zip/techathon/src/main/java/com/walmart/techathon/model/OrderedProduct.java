package com.walmart.techathon.model;

public class OrderedProduct {
	
	private Product product;
	private Integer quantityOrdered;
	private ProductQuantityCode productQuantityCode;
	
	

}
