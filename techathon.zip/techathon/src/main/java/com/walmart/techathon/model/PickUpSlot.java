package com.walmart.techathon.model;

import java.time.LocalDate;
import java.time.LocalDateTime;


public class PickUpSlot {
	
	private LocalDate pickupaDate;
	private LocalDateTime slotStartTime;
	private LocalDateTime slotEndTime;
	private boolean isActive;
	

}
