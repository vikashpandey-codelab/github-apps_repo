package com.walmart.techathon.service;

import java.util.List;

import com.walmart.techathon.model.Product;

public class ProductService {
	
	List<Product> getProducts(){
		return null;
		
	}

}
