package com.walmart.techathon.model;

import java.util.List;

public class SharedOrder {
	
	private String sharedOrderId;
	private String userId;
	private PickUpSlot pickUpSlot;
	private SharedOrderPickUpPoint pickupPoint;
	private double totalOrderValue;
	private String store_no;
	private List<OrderedProduct> orderedItems;
	
	
	
	
	

}
