package com.walmart.techathon.model;

public class User {

}
