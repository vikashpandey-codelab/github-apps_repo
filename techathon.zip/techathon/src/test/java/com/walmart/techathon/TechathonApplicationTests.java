package com.walmart.techathon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechathonApplicationTests {

	@Test
	void contextLoads() {
	}

}
